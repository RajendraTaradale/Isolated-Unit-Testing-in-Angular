import { ProductComponent } from './ProductListComponent';
import { of } from 'rxjs';

describe('UsersComponent', () => {
  let component: ProductComponent;
  let users;
  let mockUserService;

  beforeEach(() => {
    users = [
      {id: 1, name: 'R1', strength: 8},
      {id: 2, name: 'R2', strength: 24},
      {id: 3, name: 'R3', strength: 55}
    ];

    mockUserService = jasmine.createSpyObj(['getUsers', 'addUser', 'deleteUser']);

    component = new ProductComponent(mockUserService);
  });

  describe('delete', () => {

    it('should remove the user from the Useres list', () => {
      mockUserService.deleteUser.and.returnValue(of(true));
      component.users = users;

      component.delete(users[2]);

      expect(component.users.length).toBe(2);
    });

    it('should call deleteUser', () => {
      mockUserService.deleteUser.and.returnValue(of(true));
      component.users = users;

      component.delete(users[2]);

      expect(mockUserService.deleteUser).toHaveBeenCalledWith(users[2]);
    });
  });
});
