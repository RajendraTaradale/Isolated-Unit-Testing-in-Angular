import { PasswordLength } from './PipePasswordLength';

describe('PasswordLength', () => {
  it('should display weak if strength is 5', () => {
    const pipe = new PasswordLength();

    expect(pipe.transform('abcde')).toEqual('Weak Password');
  });

  it('should display strong if strength is 10', () => {
    const pipe = new PasswordLength();

    expect(pipe.transform('rajendratd')).toEqual('Strong Password');
  });
});
