import { InMemoryDbService } from 'angular-in-memory-web-api';

export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const Users = [
      { id: 11, name: 'Rajendra One', strength: 10 },
      { id: 12, name: 'Rajendra Two', strength: 5 },
      { id: 13, name: 'Rajendra Three', strength: 8 },
      { id: 14, name: 'Rajendra Four', strength: 15 },
      { id: 15, name: 'Rajendra Five', strength: 22 },
      { id: 16, name: 'Rajendra Six', strength: 50 },
      { id: 17, name: 'Rajendra Seven', strength: 43 },
      { id: 18, name: 'Rajendra Eight', strength: 4 },
      { id: 19, name: 'Rajendra Nine', strength: 18 },
      { id: 20, name: 'Rajendra Ten', strength: 15 }
    ];
    return {Users};
  }
}
