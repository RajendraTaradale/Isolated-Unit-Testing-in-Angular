import { Injectable } from '@angular/core';

@Injectable()
export class ProductListService {
  products: string[] = [];

  addProduct(pd: string) {
    this.products.push(pd);
  }

  clearProduct() {
    this.products = [];
  }

  deleteProduct(pd: string) {
      const index: number = this.products.indexOf(pd);
    if (index !== -1) {
        this.products.splice(index, 1);
    }
  }

  getProducts() {
      return this.products;
  }
}
