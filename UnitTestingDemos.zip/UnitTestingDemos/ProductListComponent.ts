import { Component, OnInit } from '@angular/core';
import { UserService } from './UserService';
import { UserModel } from './UserModel';

@Component({
  selector: 'app-users',
  template: `
  <h1> Product List </h1>`
})
export class ProductComponent implements OnInit {
     users: UserModel[];

    constructor(private userService: UserService) { }
     ngOnInit() {
      this.getUsers();
    }
      getUsers(): void {
      this.userService.getHeroes()
      .subscribe(heroes => this.users = heroes);
    }
      add(name: string): void {
      name = name.trim();
      const strength = 11;
      if (!name) { return; }
      this.userService.addUser({ name, strength } as UserModel)
        .subscribe(hero => {
          this.users.push(hero);
        });
    }
      delete(us: UserModel): void {
      this.users = this.users.filter(h => h !== us);
      this.userService.deleteUser(us).subscribe();
    }
  }
